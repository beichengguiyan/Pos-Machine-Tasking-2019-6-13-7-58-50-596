function printReceipt(collection) {
    let countElements = countSameElements(collection);
    let sInformation = specifyInformation(countElements);
    let result = outputString(sInformation);
    return result;
}

function countSameElements(collection) {
    let result = [];
    for (let i = 0; i < collection.length; i++) {
        let position = elementLocation(collection[i], result);
        if (position == -1) {
            result.push({ key: collection[i], count: 1 });
        } else {
            result[position].count++;
        }
    }
    return result;
}

function elementLocation(ele, collection) {
    let result = -1;
    for (let i = 0; i < collection.length; i++) {
        if (collection[i].key == ele) {
            result = i;
            break;
        }
    }
    return result;
}

function specifyInformation(collection) {
    let data = [
        { "id": "0001", "name": "Coca Cola", "price": 3 },
        { "id": "0002", "name": "Diet Coke", "price": 4 },
        { "id": "0003", "name": "Pepsi-Cola", "price": 5 },
        { "id": "0004", "name": "Mountain Dew", "price": 6 },
        { "id": "0005", "name": "Dr Pepper", "price": 7 },
        { "id": "0006", "name": "Sprite", "price": 8 },
        { "id": "0007", "name": "Diet Pepsi", "price": 9 },
        { "id": "0008", "name": "Diet Mountain Dew", "price": 10 },
        { "id": "0009", "name": "Diet Dr Pepper", "price": 11 },
        { "id": "0010", "name": "Fanta", "price": 12 }
    ];
    let result = collection;
    for (let i = 0; i < result.length; i++) {
        for (let j = 0; j < data.length; j++) {
            if (result[i].key == data[j].id) {
                result[i].name = data[j].name;
                result[i].price = data[j].price;
                break;
            }
        }
    }
    return result;
}

function outputString(collection) {
    let result = "";
    result = result + "Receipts\n------------------------------------------------------------\n";
    for (let i = 0; i < collection.length; i++) {
        result = result + collection[i].name;
        for (let j = 0; j < (32 - collection[i].name.length); j++) {
            result = result + " ";
        }
        result = result + collection[i].price;
        for (let k = 0; k < (11 - collection[i].price.toString().length); k++) {
            result = result + " ";
        }
        result = result + collection[i].count;
        result = result + "\n"
    }
    result = result + "------------------------------------------------------------\nPrice: ";
    result = result + sumPrice(collection);
    return result;
}

function sumPrice(collection) {
    let price = 0;
    for (let i = 0; i < collection.length; i++) {
        let subPrice = 0;
        subPrice = collection[i].price * collection[i].count;
        price = price + subPrice;
    }
    return price;
}

module.exports = { printReceipt, countSameElements,  specifyInformation, outputString, sumPrice };

