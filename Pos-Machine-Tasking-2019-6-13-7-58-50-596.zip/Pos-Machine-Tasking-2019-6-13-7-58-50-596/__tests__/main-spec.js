const { printReceipt, countSameElements, specifyInformation, outputString, sumPrice } = require('../main');

it('should print receipt', () => {
    //given
    let collection = ['0001', '0003', '0005', '0003'];
    //when
    const result = printReceipt(collection);
    //then
    expect(result).toBe("Receipts\n------------------------------------------------------------\nCoca Cola                       3          1\nPepsi-Cola                      5          2\nDr Pepper                       7          1\n------------------------------------------------------------\nPrice: 20");
});

it('should return array', () => {
    //given
    let collection = ['0001', '0003', '0005', '0003'];
    //when
    const result = countSameElements(collection);
    //then
    expect(result[1].key).toBe("0003");
});

it('should specify information', () => {
    //given
    let collection = [{ key: '0001', count: 1 }, { key: '0003', count: 2 }, { key: '0005', count: 1 }];
    //when
    const result = specifyInformation(collection);
    //then
    expect(result[0].name).toBe("Coca Cola");
    expect(result[0].price).toBe(3);
});

it('should output string', () => {
    //given
    let collection = [{ key: '0001', count: 1, name: "Coca Cola", price: 3 },
    { key: '0003', count: 2, name: "Pepsi-Cola", price: 5 },
    { key: '0005', count: 1, name: "Dr Pepper", price: 7 }];
    //when
    const result = outputString(collection);
    //then
    expect(result).toBe("Receipts\n------------------------------------------------------------\nCoca Cola                       3          1\nPepsi-Cola                      5          2\nDr Pepper                       7          1\n------------------------------------------------------------\nPrice: 20");
});

it('should calculate the total price', () => {
    //given
    let collection = [{ key: '0001', count: 1, name: "Coca Cola", price: 3 },
    { key: '0003', count: 2, name: "Pepsi-Cola", price: 5 },
    { key: '0005', count: 1, name: "Dr Pepper", price: 7 }];
    //when
    const result = sumPrice(collection);
    //then
    expect(result).toBe(20);
});